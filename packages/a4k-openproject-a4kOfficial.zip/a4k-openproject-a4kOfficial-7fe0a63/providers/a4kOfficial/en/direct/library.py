# -*- coding: utf-8 -*-
from providerModules.a4kOfficial.core.library import LibraryCore


class sources(LibraryCore):
    def __init__(self):
        super().__init__()
