# -*- coding: utf-8 -*-
from providerModules.a4kOfficial import common

__all__ = common.get_all_relative_py_files(__file__)
