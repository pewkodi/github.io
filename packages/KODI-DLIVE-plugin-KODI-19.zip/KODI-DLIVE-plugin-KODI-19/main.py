import kodi_dlive

if __name__ == '__main__':
    kodi_dlive.plugin.run()
