# -*- coding: utf-8 -*-

import resources.lib.addon as addon

# Runs the add-on from here.
if __name__ == "__main__":
    addon.run()
